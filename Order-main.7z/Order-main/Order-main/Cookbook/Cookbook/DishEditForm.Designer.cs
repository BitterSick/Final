﻿namespace Cookbook
{
    partial class DishEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView_AvIng = new DataGridView();
            txtDescription = new TextBox();
            txtName = new TextBox();
            dataGridView_SelIng = new DataGridView();
            SaveEdit_Button = new Button();
            tableLayoutPanel3 = new TableLayoutPanel();
            pictureBoxDish = new PictureBox();
            btnBrowse = new Button();
            btnRemovePic = new Button();
            tableLayoutPanel2 = new TableLayoutPanel();
            label5 = new Label();
            label6 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView_AvIng).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_SelIng).BeginInit();
            tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxDish).BeginInit();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView_AvIng
            // 
            dataGridView_AvIng.AllowUserToAddRows = false;
            dataGridView_AvIng.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_AvIng.Dock = DockStyle.Fill;
            dataGridView_AvIng.Location = new Point(3, 37);
            dataGridView_AvIng.Name = "dataGridView_AvIng";
            dataGridView_AvIng.RowHeadersWidth = 62;
            dataGridView_AvIng.Size = new Size(479, 515);
            dataGridView_AvIng.TabIndex = 12;
            dataGridView_AvIng.CellContentClick += dataGridView_AvIng_CellContentClick;
            // 
            // txtDescription
            // 
            txtDescription.Dock = DockStyle.Fill;
            txtDescription.Location = new Point(139, 52);
            txtDescription.Margin = new Padding(4, 5, 4, 5);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(547, 31);
            txtDescription.TabIndex = 9;
            // 
            // txtName
            // 
            txtName.Dock = DockStyle.Fill;
            txtName.Location = new Point(139, 5);
            txtName.Margin = new Padding(4, 5, 4, 5);
            txtName.Name = "txtName";
            txtName.Size = new Size(547, 31);
            txtName.TabIndex = 8;
            // 
            // dataGridView_SelIng
            // 
            dataGridView_SelIng.AllowUserToAddRows = false;
            dataGridView_SelIng.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView_SelIng.Location = new Point(488, 37);
            dataGridView_SelIng.Name = "dataGridView_SelIng";
            dataGridView_SelIng.RowHeadersWidth = 62;
            dataGridView_SelIng.Size = new Size(480, 509);
            dataGridView_SelIng.TabIndex = 13;
            dataGridView_SelIng.CellContentClick += dataGridView_SelIng_CellContentClick;
            // 
            // SaveEdit_Button
            // 
            SaveEdit_Button.Dock = DockStyle.Fill;
            SaveEdit_Button.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            SaveEdit_Button.Location = new Point(488, 558);
            SaveEdit_Button.Name = "SaveEdit_Button";
            SaveEdit_Button.Size = new Size(480, 60);
            SaveEdit_Button.TabIndex = 14;
            SaveEdit_Button.Text = "Save";
            SaveEdit_Button.UseVisualStyleBackColor = true;
            SaveEdit_Button.Click += SaveEdit_Button_Click;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 32.3377953F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 67.6622F));
            tableLayoutPanel3.Controls.Add(pictureBoxDish, 1, 0);
            tableLayoutPanel3.Controls.Add(btnBrowse, 0, 0);
            tableLayoutPanel3.Controls.Add(btnRemovePic, 0, 1);
            tableLayoutPanel3.Location = new Point(15, 140);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 90.221405F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 9.778598F));
            tableLayoutPanel3.Size = new Size(971, 542);
            tableLayoutPanel3.TabIndex = 17;
            // 
            // pictureBoxDish
            // 
            pictureBoxDish.Dock = DockStyle.Fill;
            pictureBoxDish.Location = new Point(317, 3);
            pictureBoxDish.Name = "pictureBoxDish";
            pictureBoxDish.Size = new Size(651, 483);
            pictureBoxDish.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxDish.TabIndex = 12;
            pictureBoxDish.TabStop = false;
            // 
            // btnBrowse
            // 
            btnBrowse.Dock = DockStyle.Bottom;
            btnBrowse.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnBrowse.Location = new Point(3, 440);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(308, 46);
            btnBrowse.TabIndex = 13;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = true;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // btnRemovePic
            // 
            btnRemovePic.Dock = DockStyle.Top;
            btnRemovePic.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnRemovePic.Location = new Point(3, 492);
            btnRemovePic.Name = "btnRemovePic";
            btnRemovePic.Size = new Size(308, 47);
            btnRemovePic.TabIndex = 14;
            btnRemovePic.Text = "Remove picture";
            btnRemovePic.UseVisualStyleBackColor = true;
            btnRemovePic.Click += btnRemovePic_Click;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(label5, 0, 0);
            tableLayoutPanel2.Controls.Add(label6, 1, 0);
            tableLayoutPanel2.Controls.Add(dataGridView_AvIng, 0, 1);
            tableLayoutPanel2.Controls.Add(SaveEdit_Button, 1, 2);
            tableLayoutPanel2.Controls.Add(dataGridView_SelIng, 1, 1);
            tableLayoutPanel2.Location = new Point(15, 688);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 3;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 5.524862F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 83.9779F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 10.4972372F));
            tableLayoutPanel2.Size = new Size(971, 621);
            tableLayoutPanel2.TabIndex = 18;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(3, 0);
            label5.Name = "label5";
            label5.Size = new Size(479, 34);
            label5.TabIndex = 8;
            label5.Text = "Available Ingredients:";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label6.Location = new Point(488, 0);
            label6.Name = "label6";
            label6.Size = new Size(480, 34);
            label6.TabIndex = 9;
            label6.Text = "Selected Ingredients:";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.5814648F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80.41853F));
            tableLayoutPanel1.Controls.Add(label3, 0, 0);
            tableLayoutPanel1.Controls.Add(label4, 0, 1);
            tableLayoutPanel1.Controls.Add(txtName, 1, 0);
            tableLayoutPanel1.Controls.Add(txtDescription, 1, 1);
            tableLayoutPanel1.Location = new Point(18, 39);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(690, 95);
            tableLayoutPanel1.TabIndex = 19;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(129, 47);
            label3.TabIndex = 2;
            label3.Text = "Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Fill;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(3, 47);
            label4.Name = "label4";
            label4.Size = new Size(129, 48);
            label4.TabIndex = 3;
            label4.Text = "Description";
            // 
            // DishEditForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1003, 1319);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(tableLayoutPanel2);
            Controls.Add(tableLayoutPanel3);
            MinimumSize = new Size(1025, 1375);
            Name = "DishEditForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DishEditForm";
            Load += MealEditForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView_AvIng).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView_SelIng).EndInit();
            tableLayoutPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBoxDish).EndInit();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion


        private DataGridView dataGridView_AvIng;
        private TextBox txtDescription;
        private TextBox txtName;
        private DataGridView dataGridView_SelIng;
        private Button SaveEdit_Button;
        private TableLayoutPanel tableLayoutPanel3;
        private PictureBox pictureBoxDish;
        private Button btnBrowse;
        private Button btnRemovePic;
        private TableLayoutPanel tableLayoutPanel2;
        private Label label5;
        private Label label6;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label3;
        private Label label4;
    }
}