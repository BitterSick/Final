﻿namespace Cookbook
{
    partial class RecipeDetailUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            dgv_Ingredients = new DataGridView();
            txtInstructions = new TextBox();
            pictureBoxDish = new PictureBox();
            tableLayoutPanel4 = new TableLayoutPanel();
            btn_Close = new Button();
            txtName = new TextBox();
            txtDifficulty = new TextBox();
            txtTime = new TextBox();
            label3 = new Label();
            Difficulty = new Label();
            label5 = new Label();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_Ingredients).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxDish).BeginInit();
            tableLayoutPanel4.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 82);
            label1.Name = "label1";
            label1.Size = new Size(0, 25);
            label1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.24138F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 66.75862F));
            tableLayoutPanel1.Controls.Add(dgv_Ingredients, 0, 0);
            tableLayoutPanel1.Controls.Add(txtInstructions, 1, 0);
            tableLayoutPanel1.Controls.Add(pictureBoxDish, 1, 1);
            tableLayoutPanel1.Location = new Point(3, 184);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 63.3240471F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 36.6759529F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(1577, 1077);
            tableLayoutPanel1.TabIndex = 2;
            // 
            // dgv_Ingredients
            // 
            dgv_Ingredients.AllowUserToAddRows = false;
            dgv_Ingredients.AllowUserToDeleteRows = false;
            dgv_Ingredients.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgv_Ingredients.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_Ingredients.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Ingredients.Location = new Point(3, 3);
            dgv_Ingredients.Name = "dgv_Ingredients";
            dgv_Ingredients.RowHeadersWidth = 62;
            dgv_Ingredients.Size = new Size(518, 676);
            dgv_Ingredients.TabIndex = 2;
            // 
            // txtInstructions
            // 
            txtInstructions.Dock = DockStyle.Fill;
            txtInstructions.Font = new Font("Arial", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtInstructions.Location = new Point(527, 3);
            txtInstructions.Multiline = true;
            txtInstructions.Name = "txtInstructions";
            txtInstructions.ReadOnly = true;
            txtInstructions.Size = new Size(1047, 676);
            txtInstructions.TabIndex = 3;
            // 
            // pictureBoxDish
            // 
            pictureBoxDish.Dock = DockStyle.Fill;
            pictureBoxDish.Location = new Point(527, 685);
            pictureBoxDish.Name = "pictureBoxDish";
            pictureBoxDish.Size = new Size(1047, 389);
            pictureBoxDish.TabIndex = 4;
            pictureBoxDish.TabStop = false;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 3;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.7191935F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.2787609F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 73.00885F));
            tableLayoutPanel4.Controls.Add(btn_Close, 0, 1);
            tableLayoutPanel4.Controls.Add(txtName, 2, 0);
            tableLayoutPanel4.Controls.Add(txtDifficulty, 2, 1);
            tableLayoutPanel4.Controls.Add(txtTime, 2, 2);
            tableLayoutPanel4.Controls.Add(label3, 1, 0);
            tableLayoutPanel4.Controls.Add(Difficulty, 1, 1);
            tableLayoutPanel4.Controls.Add(label5, 1, 2);
            tableLayoutPanel4.Location = new Point(6, 3);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 3;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 32.7165031F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 34.6029434F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 32.6805534F));
            tableLayoutPanel4.Size = new Size(904, 160);
            tableLayoutPanel4.TabIndex = 17;
            // 
            // btn_Close
            // 
            btn_Close.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btn_Close.Location = new Point(3, 55);
            btn_Close.Name = "btn_Close";
            btn_Close.Size = new Size(107, 49);
            btn_Close.TabIndex = 18;
            btn_Close.Text = "←Back";
            btn_Close.UseVisualStyleBackColor = true;
            btn_Close.Click += btn_Close_Click;
            // 
            // txtName
            // 
            txtName.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.Location = new Point(246, 3);
            txtName.Name = "txtName";
            txtName.ReadOnly = true;
            txtName.Size = new Size(655, 38);
            txtName.TabIndex = 5;
            // 
            // txtDifficulty
            // 
            txtDifficulty.Font = new Font("Arial Rounded MT Bold", 13F);
            txtDifficulty.Location = new Point(246, 55);
            txtDifficulty.Name = "txtDifficulty";
            txtDifficulty.ReadOnly = true;
            txtDifficulty.Size = new Size(655, 38);
            txtDifficulty.TabIndex = 6;
            // 
            // txtTime
            // 
            txtTime.Font = new Font("Arial Rounded MT Bold", 13F);
            txtTime.Location = new Point(246, 110);
            txtTime.Name = "txtTime";
            txtTime.ReadOnly = true;
            txtTime.Size = new Size(655, 38);
            txtTime.TabIndex = 18;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(136, 0);
            label3.Name = "label3";
            label3.Size = new Size(104, 52);
            label3.TabIndex = 4;
            label3.Text = "Name";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Difficulty
            // 
            Difficulty.AutoSize = true;
            Difficulty.Dock = DockStyle.Fill;
            Difficulty.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Difficulty.Location = new Point(136, 52);
            Difficulty.Name = "Difficulty";
            Difficulty.Size = new Size(104, 55);
            Difficulty.TabIndex = 0;
            Difficulty.Text = "Difficulty";
            Difficulty.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Fill;
            label5.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(136, 107);
            label5.Name = "label5";
            label5.Size = new Size(104, 53);
            label5.TabIndex = 1;
            label5.Text = "Time";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // RecipeDetailUC
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tableLayoutPanel4);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(label1);
            MinimumSize = new Size(1600, 1300);
            Name = "RecipeDetailUC";
            Size = new Size(1600, 1300);
            Load += RecipeDetailUC_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_Ingredients).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxDish).EndInit();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TableLayoutPanel tableLayoutPanel1;
        private DataGridView dgv_Ingredients;
        private TextBox txtInstructions;
        private TableLayoutPanel tableLayoutPanel4;
        private Label label3;
        private Label Difficulty;
        private Label label5;
        private TextBox txtName;
        private TextBox txtTime;
        private TextBox txtDifficulty;
        private PictureBox pictureBoxDish;
        private Button btn_Close;
    }
}
