﻿namespace Cookbook
{
    partial class IngredientsList
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Ing_contextMenuStrip = new ContextMenuStrip(components);
            addToolStripMenuItem = new ToolStripMenuItem();
            editToolStripMenuItem = new ToolStripMenuItem();
            deleteToolStripMenuItem = new ToolStripMenuItem();
            tableLayoutPanel1 = new TableLayoutPanel();
            IngDataGridView = new DataGridView();
            btnClose = new Button();
            label1 = new Label();
            Ing_contextMenuStrip.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)IngDataGridView).BeginInit();
            SuspendLayout();
            // 
            // Ing_contextMenuStrip
            // 
            Ing_contextMenuStrip.ImageScalingSize = new Size(24, 24);
            Ing_contextMenuStrip.Items.AddRange(new ToolStripItem[] { addToolStripMenuItem, editToolStripMenuItem, deleteToolStripMenuItem });
            Ing_contextMenuStrip.Name = "contextMenuStrip1";
            Ing_contextMenuStrip.Size = new Size(135, 100);
            // 
            // addToolStripMenuItem
            // 
            addToolStripMenuItem.Name = "addToolStripMenuItem";
            addToolStripMenuItem.Size = new Size(134, 32);
            addToolStripMenuItem.Text = "Add";
            addToolStripMenuItem.Click += addToolStripMenuItem_Click;
            // 
            // editToolStripMenuItem
            // 
            editToolStripMenuItem.Name = "editToolStripMenuItem";
            editToolStripMenuItem.Size = new Size(134, 32);
            editToolStripMenuItem.Text = "Edit";
            editToolStripMenuItem.Click += editToolStripMenuItem_Click;
            // 
            // deleteToolStripMenuItem
            // 
            deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            deleteToolStripMenuItem.Size = new Size(134, 32);
            deleteToolStripMenuItem.Text = "Delete";
            deleteToolStripMenuItem.Click += deleteToolStripMenuItem_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(IngDataGridView, 0, 2);
            tableLayoutPanel1.Controls.Add(btnClose, 0, 1);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 2.72F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 3.76F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 93.52F));
            tableLayoutPanel1.Size = new Size(1650, 1300);
            tableLayoutPanel1.TabIndex = 19;
            // 
            // IngDataGridView
            // 
            IngDataGridView.AllowUserToAddRows = false;
            IngDataGridView.AllowUserToOrderColumns = true;
            IngDataGridView.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            IngDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            IngDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            IngDataGridView.Location = new Point(3, 86);
            IngDataGridView.Name = "IngDataGridView";
            IngDataGridView.ReadOnly = true;
            IngDataGridView.RowHeadersWidth = 62;
            IngDataGridView.Size = new Size(1644, 1211);
            IngDataGridView.TabIndex = 17;
            IngDataGridView.CellMouseDown += IngDataGridView_CellMouseDown;
            // 
            // btnClose
            // 
            btnClose.Dock = DockStyle.Left;
            btnClose.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnClose.Location = new Point(3, 38);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(87, 42);
            btnClose.TabIndex = 18;
            btnClose.Text = "←Back";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Bottom;
            label1.Font = new Font("Arial", 13F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 5);
            label1.Name = "label1";
            label1.Size = new Size(1644, 30);
            label1.TabIndex = 19;
            label1.Text = "List of ingredients";
            // 
            // IngredientsList
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ContextMenuStrip = Ing_contextMenuStrip;
            Controls.Add(tableLayoutPanel1);
            Name = "IngredientsList";
            Size = new Size(1650, 1300);
            Load += IngredientsList_Load;
            Ing_contextMenuStrip.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)IngDataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private ContextMenuStrip Ing_contextMenuStrip;
        private ToolStripMenuItem addToolStripMenuItem;
        private ToolStripMenuItem editToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private TableLayoutPanel tableLayoutPanel1;
        public DataGridView IngDataGridView;
        private Button btnClose;
        private Label label1;
    }
}
