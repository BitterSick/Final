﻿using Ingredients;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{

    public partial class IngList : Form
    {
        
        private SqlDataAdapter dataAdapter;
        private DataTable dataTable;
        private int selectedRowIndex;
        
        public IngList()
        {
            InitializeComponent();
        }

        private void IngList_Load(object sender, EventArgs e)
        {
            BindData();
        }

        public void BindData()
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new("SELECT * from Ingredients", con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            if (IngDataGridView != null)
            {
                IngDataGridView.DataSource = dataTable;
                IngDataGridView.Refresh();
                dataTable.AcceptChanges();
            }
        }

        //private void addToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    using (IngredientsAddForm ingAddForm = new IngredientsAddForm())
        //    {
        //        if (ingAddForm.ShowDialog() == DialogResult.OK)
        //        {
        //            ingAddForm.Close();
        //            BindData();
        //        }
        //    }
        //}

        private void DeleteRowFromDatabase(int id)
        {
            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
            string query = "DELETE FROM Ingredients WHERE IDIngredient = @IDIngredient";

            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                //using SqlCommand cmd = new SqlConnection(connectionString); THIS CODE DOES NOT WORK
                SqlCommand cmd = new SqlCommand(query, conn);
                {
                    cmd.Parameters.AddWithValue("@IDIngredient", id);

                    try
                    {
                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Row deleted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Invalid ID.");
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }

                }
            }
        }
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IngDataGridView.SelectedCells.Count > 0)
            {
                if (IngDataGridView.IsCurrentCellInEditMode)
                {
                    IngDataGridView.EndEdit();
                }

                int selectedRowIndex = IngDataGridView.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = IngDataGridView.Rows[selectedRowIndex];

                if (!selectedRow.IsNewRow)
                {
                    int id = Convert.ToInt32(selectedRow.Cells["IDIngredient"].Value);

                    DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this row?", "Delete Row", MessageBoxButtons.YesNo);

                    if (dialogResult == DialogResult.Yes)
                    {
                        DeleteRowFromDatabase(id);

                        //dataGridView1.Rows.RemoveAt(selectedRowIndex); - Uncommitted new row cannot be deleted

                        BindData();
                    }
                }
                else
                {
                    MessageBox.Show("Cannot delete an uncommitted new row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("No cell selected.");
            }
        }
        private void IngDataGridView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e) //Selects a row where the cursor is when right-clicked
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                IngDataGridView.ClearSelection();
                IngDataGridView.Rows[e.RowIndex].Selected = true;
                selectedRowIndex = e.RowIndex;

                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        //private void editToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    if (IngDataGridView.SelectedRows.Count > 0)
        //    {
        //        DataGridViewRow selectedRow = IngDataGridView.SelectedRows[0];

        //        long id = (long)IngDataGridView.SelectedRows[0].Cells["IDIngredient"].Value;
        //        string name = selectedRow.Cells["Name"].Value.ToString();
        //        string description = selectedRow.Cells["Description"].Value.ToString();
        //        string unitType = selectedRow.Cells["UnitType"].Value.ToString();

        //        IngEditForm ingEditForm = new IngEditForm(id, name, description, unitType);
        //        ingEditForm.ShowDialog();
        //        BindData();
        //    }
        //}
    }
}
