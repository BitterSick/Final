﻿namespace Cookbook
{
    partial class Ingredients_AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CloseButton = new Button();
            Add_OKButton = new Button();
            comboBox_UnitType = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            txtDescription = new TextBox();
            label5 = new Label();
            txtName = new TextBox();
            label4 = new Label();
            SuspendLayout();
            // 
            // CloseButton
            // 
            CloseButton.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            CloseButton.Location = new Point(467, 236);
            CloseButton.Name = "CloseButton";
            CloseButton.Size = new Size(191, 58);
            CloseButton.TabIndex = 27;
            CloseButton.Text = "Close";
            CloseButton.UseVisualStyleBackColor = true;
            CloseButton.Click += CloseButton_Click;
            // 
            // Add_OKButton
            // 
            Add_OKButton.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            Add_OKButton.Location = new Point(46, 236);
            Add_OKButton.Name = "Add_OKButton";
            Add_OKButton.Size = new Size(177, 58);
            Add_OKButton.TabIndex = 26;
            Add_OKButton.Text = "OK";
            Add_OKButton.UseVisualStyleBackColor = true;
            Add_OKButton.Click += Add_OKButton_Click;
            // 
            // comboBox_UnitType
            // 
            comboBox_UnitType.FormattingEnabled = true;
            comboBox_UnitType.Items.AddRange(new object[] { "Type1", "Type2" });
            comboBox_UnitType.Location = new Point(176, 181);
            comboBox_UnitType.Name = "comboBox_UnitType";
            comboBox_UnitType.Size = new Size(482, 33);
            comboBox_UnitType.TabIndex = 25;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(46, 181);
            label2.Name = "label2";
            label2.Size = new Size(103, 28);
            label2.TabIndex = 24;
            label2.Text = "Unit Type";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label1.Location = new Point(256, 9);
            label1.Name = "label1";
            label1.Size = new Size(158, 41);
            label1.TabIndex = 23;
            label1.Text = "Add Form";
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(176, 133);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(482, 31);
            txtDescription.TabIndex = 20;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(46, 133);
            label5.Name = "label5";
            label5.Size = new Size(121, 28);
            label5.TabIndex = 22;
            label5.Text = "Description";
            // 
            // txtName
            // 
            txtName.Location = new Point(176, 86);
            txtName.Name = "txtName";
            txtName.Size = new Size(482, 31);
            txtName.TabIndex = 19;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(46, 86);
            label4.Name = "label4";
            label4.Size = new Size(68, 28);
            label4.TabIndex = 21;
            label4.Text = "Name";
            // 
            // Ingredients_AddForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(683, 323);
            Controls.Add(CloseButton);
            Controls.Add(Add_OKButton);
            Controls.Add(comboBox_UnitType);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDescription);
            Controls.Add(label5);
            Controls.Add(txtName);
            Controls.Add(label4);
            Name = "Ingredients_AddForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Ingredients_AddForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CloseButton;
        private Button Add_OKButton;
        private ComboBox comboBox_UnitType;
        private Label label2;
        private Label label1;
        private TextBox txtDescription;
        private Label label5;
        private TextBox txtName;
        private Label label4;
    }
}