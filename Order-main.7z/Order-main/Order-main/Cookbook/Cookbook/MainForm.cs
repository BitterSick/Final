using System.Data.SqlClient;
using System;
using System.Data;
using Microsoft.VisualBasic;
using System.Drawing;
using System.Linq.Expressions;
using System.Data.Common;
using System.Drawing.Text;
using Cookbook;
using System.Security.Cryptography;




namespace Ingredients

{
    public partial class MainForm : Form
    {
        private SqlDataAdapter dataAdapter;
        private DataTable dataTable;
        private int selectedRowIndex;
        private IngredientsList ingredientsListControl;
        public MainForm()
        {
            InitializeComponent();
            this.ContextMenuStrip = contextMenuStrip2;

        }

        void BindData()
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new("SELECT * FROM Test", con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            Dishes_DataGridView.DataSource = dt;
        }


        public void MainForm_Load(object sender, EventArgs e)
        {
            //BindData();
            //RefreshData();
            LoadData_Meals();
            Dishes_DataGridView.ClearSelection();
            Dishes_DataGridView.CurrentCell = null;

            //Dishes_DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            Dishes_DataGridView.Columns[0].Width = 70;
            //Dishes_DataGridView.Columns[1].Width = 150;
            Dishes_DataGridView.Columns[2].Width = 400;
            //Dishes_DataGridView.Columns[3].Width = 200;
            Dishes_DataGridView.Columns[4].Width = 530;
            Dishes_DataGridView.Columns[5].Width = 400;


            AddViewRecipeButtonColumn();
            Dishes_DataGridView.CellFormatting += Dishes_DataGridView_CellFormatting;
            SetupDataGridView();
            tlpCookingRec.Visible = false;
            //DefaultTextSearchBar();
            //txtSearch.GotFocus += txtSearch_GotFocus;
            //txtSearch.LostFocus += txtSearch_LostFocus;
        }


        private void RefreshData()
        {
            LoadDataIntoGrid();
        }

        private void LoadDataIntoGrid()
        {
            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Test", conn))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    Dishes_DataGridView.DataSource = dataTable;
                }
            }
        }

        private void DeleteRowFromDatabase(int id)
        {
            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
            string query = "DELETE FROM Meals WHERE IDMeal = @IDMeal";

            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                //using SqlCommand cmd = new SqlConnection(connectionString); THIS CODE DOES NOT WORK
                SqlCommand cmd = new SqlCommand(query, conn);
                {
                    cmd.Parameters.AddWithValue("@IDMeal", id);

                    try
                    {
                        conn.Open();
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Row deleted successfully.");
                            RefreshData();
                        }
                        else
                        {
                            MessageBox.Show("Invalid ID.");
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    }

                }
            }
        }

        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            int rowIndex = -1;
            if (e.Button == MouseButtons.Right)
            {
                var hit = Dishes_DataGridView.HitTest(e.X, e.Y);
                if (hit.RowIndex >= 0)
                {
                    rowIndex = hit.RowIndex;
                    Dishes_DataGridView.ClearSelection();
                    Dishes_DataGridView.Rows[hit.RowIndex].Selected = true;
                }
            }
        }

        public void LoadData_Meals()
        {
            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
            string query = "SELECT * FROM Meals";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                DataTable mealTable = new DataTable();
                adapter.Fill(mealTable);
                Dishes_DataGridView.DataSource = mealTable;
            }
        }

        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0)
            {
                Dishes_DataGridView.ClearSelection();
                Dishes_DataGridView.Rows[e.RowIndex].Selected = true;
                selectedRowIndex = e.RowIndex;

                contextMenuStrip2.Show(Cursor.Position);
            }
        }

        public void EndDataGridViewEdit()
        {
            Dishes_DataGridView.EndEdit();
        }

        private void ingredientsListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowIngredientsList();
        }

        private void ShowIngredientsList()
        {
            if (ingredientsListControl == null)
            {
                ingredientsListControl = new IngredientsList();
                ingredientsListControl.CloseRequested += IngredientsList_CloseRequested;
            }

            if (!panelContainer.Controls.Contains(ingredientsListControl))
            {
                panelContainer.Controls.Add(ingredientsListControl);
                ingredientsListControl.Dock = DockStyle.Fill;
            }
            ingredientsListControl.BringToFront();
        }

        private void IngredientsList_CloseRequested(object sender, EventArgs e)
        {
            if (ingredientsListControl != null && panelContainer.Controls.Contains(ingredientsListControl))
            {
                panelContainer.Controls.Remove(ingredientsListControl);
                ingredientsListControl = null;
            }
        }

        private void AddViewRecipeButtonColumn()
        {
            DataGridViewButtonColumn viewButton = new DataGridViewButtonColumn();
            viewButton.HeaderText = "Recipe";
            viewButton.Name = "ViewRecipe";
            viewButton.Text = "View";
            viewButton.Width = 100;
            viewButton.UseColumnTextForButtonValue = true;

            Dishes_DataGridView.Columns.Add(viewButton);
        }
        private RecipeDetailUC recipeDetail;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == Dishes_DataGridView.Columns["ViewRecipe"].Index && e.RowIndex >= 0)
            {
                int dishID = Convert.ToInt32(Dishes_DataGridView.Rows[e.RowIndex].Cells["IDMeal"].Value);

                int recipeID = GetRecipeID(dishID);
                if (recipeID > 0)
                {
                    recipeDetail = new RecipeDetailUC(dishID, recipeID);
                    recipeDetail.CloseRequested += RecipeDetail_CloseRequested;
                    panelContainer.Controls.Add(recipeDetail);
                    recipeDetail.Dock = DockStyle.Fill;
                    recipeDetail.BringToFront();
                }
                else
                {
                    MessageBox.Show("No recipe exists for this dish.", "Recipe Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void Dishes_DataGridView_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (Dishes_DataGridView.Columns[e.ColumnIndex].Name == "ViewRecipe" && e.RowIndex >= 0)
            {
                int dishID = Convert.ToInt32(Dishes_DataGridView.Rows[e.RowIndex].Cells["IDMeal"].Value);
                int recipeID = GetRecipeID(dishID);

                DataGridViewButtonCell buttonCell = Dishes_DataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex] as DataGridViewButtonCell;

                if (recipeID > 0)
                {
                    buttonCell.Style.BackColor = Color.Green;
                    buttonCell.Style.ForeColor = Color.White;
                }
            }
        }

        private int GetRecipeID(int dishID)
        {
            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = "SELECT IDRecipe FROM Recipes WHERE IDMeal = @IDMeal";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IDMeal", dishID);

                con.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : -1;
            }
        }

        public void RecipeDetail_CloseRequested(object sender, EventArgs e)
        {
            var recipeDetail = panelContainer.Controls.OfType<RecipeDetailUC>().FirstOrDefault();
            if (recipeDetail != null && panelContainer.Controls.Contains(recipeDetail))
            {
                panelContainer.Controls.Remove(recipeDetail);
                recipeDetail.Dispose();
                recipeDetail = null;

            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchValue = txtSearch.Text.Trim();

            if (Dishes_DataGridView.DataSource is BindingSource bindingSource && bindingSource.DataSource is DataTable mealTable)
            {
                if (string.IsNullOrEmpty(searchValue))
                {
                    bindingSource.RemoveFilter();
                    return;
                }
                bindingSource.Filter = $"Name LIKE '%{searchValue}%'";
            }

            else if (Dishes_DataGridView.DataSource is DataTable mealtable)
            {
                try
                {
                    if (string.IsNullOrEmpty(searchValue))
                    {
                        LoadData_Meals();
                        return;
                    }

                    var filteredData = mealtable.AsEnumerable().Where(row => row.Field<string>("Name").StartsWith(searchValue, StringComparison.OrdinalIgnoreCase));

                    if (filteredData.Any())
                    {
                        Dishes_DataGridView.DataSource = filteredData.CopyToDataTable();
                    }
                    else
                    {
                        Dishes_DataGridView.DataSource = mealtable.Clone();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error filtering dishes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void SetupDataGridView()
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new("SELECT Name FROM Ingredients", con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            DGV_Available.DataSource = dt;

            //Available ingredients datagridview
            DataGridViewButtonColumn addButtonColumn = new DataGridViewButtonColumn();
            addButtonColumn.HeaderText = "Add Ingredient";
            addButtonColumn.Name = "AddIngredient";
            addButtonColumn.Text = "+";
            addButtonColumn.Width = 100;
            addButtonColumn.UseColumnTextForButtonValue = true;
            DGV_Available.Columns.Add(addButtonColumn);

            //Selected ingredients datagridview
            DGV_Selected.Columns.Clear();
            DGV_Selected.AutoGenerateColumns = true;

            DataGridViewTextBoxColumn ingredientNameColumn = new DataGridViewTextBoxColumn();
            ingredientNameColumn.HeaderText = "Name";
            ingredientNameColumn.Name = "IngredientName";
            ingredientNameColumn.Width = 100;
            DGV_Selected.Columns.Add(ingredientNameColumn);

            DataGridViewButtonColumn removeButtonColumn = new DataGridViewButtonColumn();
            removeButtonColumn.HeaderText = "Remove";
            removeButtonColumn.Name = "RemoveIngredient";
            removeButtonColumn.Text = "X";
            removeButtonColumn.UseColumnTextForButtonValue = true;
            DGV_Selected.Columns.Add(removeButtonColumn);

            DGV_Selected.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void btFindDish_Click(object sender, EventArgs e)
        {
            if (DGV_Selected.Rows.Count < 3)
            {
                MessageBox.Show("Please select at least 3 ingredients.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selectedIngredients = DGV_Selected.Rows.Cast<DataGridViewRow>().Select(row => row.Cells["IngredientName"].Value?.ToString()).ToList();

            try
            {
                string query = @"SELECT * FROM Meals WHERE Ingredients LIKE @Ingredient1 
                                AND Ingredients LIKE @Ingredient2
                                AND Ingredients LIKE @Ingredient3";

                using (SqlConnection connection = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Ingredient1", "%" + selectedIngredients[0] + "%");
                    command.Parameters.AddWithValue("@Ingredient2", "%" + selectedIngredients[1] + "%");
                    command.Parameters.AddWithValue("@Ingredient3", "%" + selectedIngredients[2] + "%");

                    connection.Open();

                    DataTable resultTable = new DataTable();
                    resultTable.Load(command.ExecuteReader());

                    //display results
                    Dishes_DataGridView.DataSource = resultTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching dish recommendation: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DGV_Available_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == DGV_Available.Columns["AddIngredient"].Index && e.RowIndex >= 0)
            {
                string ingredientName = DGV_Available.Rows[e.RowIndex].Cells["Name"].Value.ToString();

                bool alreadyAdded = false;
                foreach (DataGridViewRow row in DGV_Selected.Rows)
                {
                    if (row.Cells["IngredientName"].Value?.ToString() == ingredientName)
                    {
                        alreadyAdded = true;
                        break;
                    }
                }
                if (!alreadyAdded)
                {
                    DGV_Selected.Rows.Add(ingredientName);
                }
            }
        }

        private void DGV_Selected_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == DGV_Selected.Columns["RemoveIngredient"].Index && e.RowIndex >= 0)
            {
                DGV_Selected.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                DGV_Selected.Rows.Clear();

                string query = "SELECT Name FROM Ingredients";
                DataTable availableIngredientsTable = new DataTable();

                using (SqlConnection connection = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    availableIngredientsTable.Load(command.ExecuteReader());
                }

                DGV_Available.DataSource = availableIngredientsTable;

                string queryDish = "SELECT * FROM Meals";
                DataTable dishTable = new DataTable();

                using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                using (SqlCommand cmd = new SqlCommand(queryDish, conn))
                {
                    conn.Open();
                    dishTable.Load(cmd.ExecuteReader());
                }

                Dishes_DataGridView.DataSource = dishTable;

            }

            catch (Exception ex)
            {
                MessageBox.Show("Error resetting selection: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCookingRec_Click(object sender, EventArgs e)
        {
            tlpCookingRec.Visible = !tlpCookingRec.Visible;
        }

        private bool DoesRecipeExist(int dishID)
        {
            bool exists = false;

            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = "SELECT COUNT(*) FROM Recipes WHERE IDMeal = @IDMeal";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@IDMeal", dishID);
                    con.Open();

                    int count = Convert.ToInt32(cmd.ExecuteScalar());
                    exists = count > 0;
                }
            }
            return exists;
        }

        private void addDishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DishAddForm dishAddForm = new DishAddForm();
            if (dishAddForm.ShowDialog() == DialogResult.OK)
            {
                LoadData_Meals();
                dishAddForm.Close();
            }
        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {
            if (Dishes_DataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Dishes_DataGridView.SelectedRows[0];
                int dishID = Convert.ToInt32(selectedRow.Cells["IDMeal"].Value);
                string dishName = selectedRow.Cells["Name"].Value.ToString();

                if (DoesRecipeExist(dishID))
                {
                    MessageBox.Show($"A recipe already exists for this dish: {dishName}. You cannot create another recipe.", "Recipe Exists", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                AddRecipe recipeAdd = new AddRecipe(dishID, dishName);
                recipeAdd.ShowDialog();
            }
        }

        private void editDishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Dishes_DataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Dishes_DataGridView.SelectedRows[0];

                int mealID = Convert.ToInt32(selectedRow.Cells["IDMeal"].Value);
                string name = selectedRow.Cells["Name"].Value.ToString();
                string description = selectedRow.Cells["Description"].Value.ToString();
                byte[] pictureData = null;
                using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    string query = "SELECT Picture FROM Meals WHERE IDMeal = @IDMeal";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@IDMeal", mealID);
                        con.Open();
                        pictureData = cmd.ExecuteScalar() as byte[];
                    }
                }
                DishEditForm editForm = new DishEditForm(mealID, name, description, pictureData);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadData_Meals();
                }
            }
        }

        private void deleteDishToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Dishes_DataGridView.SelectedCells.Count > 0)
            {
                if (Dishes_DataGridView.IsCurrentCellInEditMode)
                {
                    Dishes_DataGridView.EndEdit();
                }

                int selectedRowIndex = Dishes_DataGridView.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = Dishes_DataGridView.Rows[selectedRowIndex];

                if (!selectedRow.IsNewRow)
                {
                    int id = Convert.ToInt32(selectedRow.Cells["IDMeal"].Value);

                    DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this row?", "Delete Row", MessageBoxButtons.YesNo);

                    if (dialogResult == DialogResult.Yes)
                    {
                        DeleteRowFromDatabase(id);

                        //dataGridView1.Rows.RemoveAt(selectedRowIndex); - Uncommitted new row cannot be deleted

                        LoadData_Meals();
                    }
                }
                else
                {
                    MessageBox.Show("Cannot delete an uncommitted new row.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("No cell selected.");
            }
        }

        private void CreateNewtoolStripMenuItem_Click(object sender, EventArgs e)
        {
            DishAddForm dishAddForm = new DishAddForm();
            if (dishAddForm.ShowDialog() == DialogResult.OK)
            {
                LoadData_Meals();
                dishAddForm.Close();
            }
        }

        private void editRecipeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Dishes_DataGridView.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Dishes_DataGridView.SelectedRows[0];
                int dishID = Convert.ToInt32(selectedRow.Cells["IDMeal"].Value);
                string dishName = selectedRow.Cells["Name"].Value.ToString();

                int recipeID = GetRecipeID(dishID);

                if (recipeID > 0)
                {
                    EditRecipe recipeEdit = new EditRecipe(dishID, recipeID, dishName);
                    recipeEdit.ShowDialog();
                }
                else
                {
                    MessageBox.Show("No recipe exists for the selected dish.", "Edit Recipe", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

        }

        private RecipeList recipeList;
        private void recipeListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (recipeList == null)
            {
                recipeList = new RecipeList();
                recipeList.CloseRequested += RecipeList_CloseRequested;
            }

            if (!panelContainer.Controls.Contains(recipeList))
            {
                panelContainer.Controls.Add(recipeList);
                recipeList.Dock = DockStyle.Fill;
            }
            recipeList.BringToFront();
        }

        private void RecipeList_CloseRequested(object sender, EventArgs e)
        {
            if (recipeList != null && panelContainer.Controls.Contains(recipeList))
            {
                panelContainer.Controls.Remove(recipeList);
                recipeList.Dispose();
                recipeList = null;
            }
        }

        private void exitAppliationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
