﻿namespace Cookbook
{
    partial class RecipeList
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            dgv_Recipes = new DataGridView();
            txtBoxSearch = new TextBox();
            CloseBtn = new Button();
            label1 = new Label();
            label2 = new Label();
            panelRecipe = new Panel();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_Recipes).BeginInit();
            panelRecipe.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(dgv_Recipes, 0, 4);
            tableLayoutPanel1.Controls.Add(txtBoxSearch, 0, 3);
            tableLayoutPanel1.Controls.Add(CloseBtn, 0, 1);
            tableLayoutPanel1.Controls.Add(label1, 0, 2);
            tableLayoutPanel1.Controls.Add(label2, 0, 0);
            tableLayoutPanel1.Location = new Point(21, 43);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 4.32972527F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.245629F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 2.58118224F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 3.58034968F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 84.51291F));
            tableLayoutPanel1.Size = new Size(1547, 1201);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // dgv_Recipes
            // 
            dgv_Recipes.AllowUserToAddRows = false;
            dgv_Recipes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_Recipes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_Recipes.Location = new Point(3, 188);
            dgv_Recipes.Name = "dgv_Recipes";
            dgv_Recipes.RowHeadersWidth = 62;
            dgv_Recipes.Size = new Size(1526, 1010);
            dgv_Recipes.TabIndex = 0;
            dgv_Recipes.CellContentClick += dgv_Recipes_CellContentClick;
            // 
            // txtBoxSearch
            // 
            txtBoxSearch.Location = new Point(3, 146);
            txtBoxSearch.Name = "txtBoxSearch";
            txtBoxSearch.Size = new Size(655, 31);
            txtBoxSearch.TabIndex = 1;
            txtBoxSearch.TextChanged += txtBoxSearch_TextChanged;
            // 
            // CloseBtn
            // 
            CloseBtn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            CloseBtn.Location = new Point(3, 54);
            CloseBtn.Name = "CloseBtn";
            CloseBtn.Size = new Size(112, 56);
            CloseBtn.TabIndex = 1;
            CloseBtn.Text = "←Back";
            CloseBtn.UseVisualStyleBackColor = true;
            CloseBtn.Click += CloseBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Bottom;
            label1.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 119);
            label1.Name = "label1";
            label1.Size = new Size(1541, 24);
            label1.TabIndex = 2;
            label1.Text = "Search recipe";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Bottom;
            label2.Font = new Font("Arial", 13F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(3, 21);
            label2.Name = "label2";
            label2.Size = new Size(1541, 30);
            label2.TabIndex = 3;
            label2.Text = "List of recipes";
            // 
            // panelRecipe
            // 
            panelRecipe.Controls.Add(tableLayoutPanel1);
            panelRecipe.Location = new Point(14, 20);
            panelRecipe.Name = "panelRecipe";
            panelRecipe.Size = new Size(1600, 1294);
            panelRecipe.TabIndex = 1;
            // 
            // RecipeList
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelRecipe);
            MinimumSize = new Size(1650, 1300);
            Name = "RecipeList";
            Size = new Size(1650, 1345);
            Load += RecipeList_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_Recipes).EndInit();
            panelRecipe.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private TextBox txtBoxSearch;
        private DataGridView dgv_Recipes;
        private Button CloseBtn;
        private Panel panelRecipe;
        private Label label1;
        private Label label2;
    }
}
