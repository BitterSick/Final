﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class DishAddForm : Form
    {
        public DishAddForm()
        {
            InitializeComponent();
        }

        private void MealAddForm_Load(object sender, EventArgs e)
        {
            LoadData_DataGridView();
            Setup_dataGridView();

            dataGridView_SelIng.CellValidating += dataGridView_SelIng_CellValidating;
            dataGridView_SelIng.CellEndEdit += dataGridView_SelIng_CellEndEdit;
        }

        private void LoadData_DataGridView()
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new("SELECT IDIngredient, Name FROM Ingredients", con);
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView_AvIng.DataSource = dt;
        }


        private void Setup_dataGridView()
        {
            //Available ingredients datagridview
            DataGridViewButtonColumn addButtonColumn = new DataGridViewButtonColumn();
            addButtonColumn.HeaderText = "Add Ingredient";
            addButtonColumn.Name = "AddIngredient";
            addButtonColumn.Text = "+";
            addButtonColumn.Width = 100;
            addButtonColumn.UseColumnTextForButtonValue = true;

            dataGridView_AvIng.Columns.Add(addButtonColumn);

            //Selected ingredients datagridview
            dataGridView_SelIng.Columns.Clear();
            dataGridView_SelIng.AutoGenerateColumns = true;

            DataGridViewTextBoxColumn ingredientNameColumn = new DataGridViewTextBoxColumn();
            ingredientNameColumn.HeaderText = "Name";
            ingredientNameColumn.Name = "IngredientName";
            ingredientNameColumn.Width = 100;
            dataGridView_SelIng.Columns.Add(ingredientNameColumn);

            //Amount column
            //DataGridViewTextBoxColumn amountColumn = new DataGridViewTextBoxColumn();
            //amountColumn.HeaderText = "Amount";
            //amountColumn.Name = "Amount";
            //amountColumn.Width = 150;
            //dataGridView_SelIng.Columns.Add(amountColumn);

            //Remove ingredient column
            DataGridViewButtonColumn removeButtonColumn = new DataGridViewButtonColumn();
            removeButtonColumn.HeaderText = "Remove";
            removeButtonColumn.Name = "RemoveIngredient";
            removeButtonColumn.Text = "X";
            removeButtonColumn.UseColumnTextForButtonValue = true;
            dataGridView_SelIng.Columns.Add(removeButtonColumn);

            dataGridView_SelIng.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

        }

        private void dataGridView_SelIng_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (dataGridView_SelIng.Columns[e.ColumnIndex].Name == "Amount")
            {
                string inputValue = e.FormattedValue.ToString();

                if (string.IsNullOrEmpty(inputValue))
                {
                    MessageBox.Show("Please enter amount for the ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Cancel = true;
                }
            }
        }

        private void dataGridView_SelIng_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView_SelIng.Columns[e.ColumnIndex].Name == "Amount")
            {
                string rawInput = dataGridView_SelIng.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString() ?? "";
                string formattedInput = rawInput.Replace(" ", "");

                dataGridView_SelIng.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = formattedInput;
            }
        }

        private void dataGridView_AvIng_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView_AvIng.Columns["AddIngredient"].Index && e.RowIndex >= 0)
            {
                string ingredientName = dataGridView_AvIng.Rows[e.RowIndex].Cells["Name"].Value.ToString();

                bool alreadyAdded = false;
                foreach (DataGridViewRow row in dataGridView_SelIng.Rows)
                {
                    if (row.Cells["IngredientName"].Value?.ToString() == ingredientName)
                    {
                        alreadyAdded = true;
                        break;
                    }
                }
                if (!alreadyAdded)
                {
                    dataGridView_SelIng.Rows.Add(ingredientName);
                }
            }
        }

        private void dataGridView_SelIng_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView_SelIng.Columns["RemoveIngredient"].Index && e.RowIndex >= 0)
            {
                dataGridView_SelIng.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            string mealName = txtName.Text;
            string mealDesc = txtDescription.Text;
            byte[] pictureData = GetImageBytes();

            if (string.IsNullOrEmpty(mealName))
            {
                MessageBox.Show("Please enter a name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dataGridView_SelIng.Rows.Count == 0)
            {
                MessageBox.Show("Please add at least 1 ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            //foreach (DataGridViewRow row in dataGridView_SelIng.Rows)
            //{
            //    var amountCell = row.Cells["Amount"].Value;
            //    if (amountCell == null || string.IsNullOrWhiteSpace(amountCell.ToString()))
            //    {
            //        MessageBox.Show("Please enter the amount for each ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //        return;
            //    }
            //}

            //string ingredientsList = string.Join(", ", dataGridView_SelIng.Rows
            //    .Cast<DataGridViewRow>()
            //    .Where(row => row.Cells["IngredientName"].Value != null && row.Cells["Amount"].Value != null)
            //    .Select(row => $"{row.Cells["Amount"].Value} {row.Cells["IngredientName"].Value}"));

            string ingredientsList = string.Join(", ", dataGridView_SelIng.Rows
                .Cast<DataGridViewRow>()
                .Where(row => row.Cells["IngredientName"].Value != null)
                .Select(row => row.Cells["IngredientName"].Value.ToString()));



            try
            {
                InsertMeal(mealName, mealDesc, ingredientsList, pictureData);
                MessageBox.Show("Meal created successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InsertMeal(string name, string description, string ingredients, byte[] pictureData)
        {
            string query = "INSERT INTO Meals (Name, Description, Ingredients, Created, Picture) OUTPUT INSERTED.IDMeal VALUES (@Name, @Description, @Ingredients, GETDATE(), @Picture)";

            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Description", description);
                cmd.Parameters.AddWithValue("@Ingredients", ingredients);
                cmd.Parameters.AddWithValue("@Picture", (object)pictureData ?? DBNull.Value);

                conn.Open();
                cmd.ExecuteScalar();
            }
        }

        private byte[] GetImageBytes()
        {
            if (pictureBoxDish.Image == null)
                return null;

            using (MemoryStream ms = new MemoryStream())
            {
                pictureBoxDish.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private void LoadImage(byte[] imageData)
        {
            if (imageData == null)
            {
                pictureBoxDish.Image = null;
                return;
            }

            using (MemoryStream ms = new MemoryStream(imageData))
            {
                pictureBoxDish.Image = Image.FromStream(ms);
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp",
                Title = "Select a picture"
            };

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxDish.Image = Image.FromFile(ofd.FileName);
            }
        }

        private void btnRemovePic_Click(object sender, EventArgs e)
        {
            if (pictureBoxDish != null)
            {
                pictureBoxDish.Image.Dispose();
                pictureBoxDish.Image = null;
            }
        }
    }
}
