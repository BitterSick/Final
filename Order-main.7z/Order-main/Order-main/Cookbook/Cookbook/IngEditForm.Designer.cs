﻿namespace Cookbook
{
    partial class Ingredients_EditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDescription = new TextBox();
            label5 = new Label();
            txtName = new TextBox();
            label4 = new Label();
            label1 = new Label();
            comboBox1 = new ComboBox();
            label2 = new Label();
            CloseButton = new Button();
            Edit_OKButton = new Button();
            SuspendLayout();
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(158, 130);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(482, 31);
            txtDescription.TabIndex = 11;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label5.Location = new Point(28, 130);
            label5.Name = "label5";
            label5.Size = new Size(121, 28);
            label5.TabIndex = 13;
            label5.Text = "Description";
            // 
            // txtName
            // 
            txtName.Location = new Point(158, 83);
            txtName.Name = "txtName";
            txtName.Size = new Size(482, 31);
            txtName.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label4.Location = new Point(28, 83);
            label4.Name = "label4";
            label4.Size = new Size(68, 28);
            label4.TabIndex = 12;
            label4.Text = "Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label1.Location = new Point(294, 9);
            label1.Name = "label1";
            label1.Size = new Size(155, 41);
            label1.TabIndex = 14;
            label1.Text = "Edit Form";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Type1", "Type2" });
            comboBox1.Location = new Point(158, 178);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(482, 33);
            comboBox1.TabIndex = 16;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label2.Location = new Point(28, 178);
            label2.Name = "label2";
            label2.Size = new Size(103, 28);
            label2.TabIndex = 15;
            label2.Text = "Unit Type";
            // 
            // CloseButton
            // 
            CloseButton.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            CloseButton.Location = new Point(449, 233);
            CloseButton.Name = "CloseButton";
            CloseButton.Size = new Size(191, 58);
            CloseButton.TabIndex = 18;
            CloseButton.Text = "Close";
            CloseButton.UseVisualStyleBackColor = true;
            CloseButton.Click += CloseButton_Click;
            // 
            // Edit_OKButton
            // 
            Edit_OKButton.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            Edit_OKButton.Location = new Point(28, 233);
            Edit_OKButton.Name = "Edit_OKButton";
            Edit_OKButton.Size = new Size(177, 58);
            Edit_OKButton.TabIndex = 17;
            Edit_OKButton.Text = "OK";
            Edit_OKButton.UseVisualStyleBackColor = true;
            Edit_OKButton.Click += Edit_OKButton_Click;
            // 
            // Ingredients_EditForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(671, 305);
            Controls.Add(CloseButton);
            Controls.Add(Edit_OKButton);
            Controls.Add(comboBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDescription);
            Controls.Add(label5);
            Controls.Add(txtName);
            Controls.Add(label4);
            Name = "Ingredients_EditForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Ingredients_EditForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDescription;
        private Label label5;
        private TextBox txtName;
        private Label label4;
        private Label label1;
        private ComboBox comboBox1;
        private Label label2;
        private Button CloseButton;
        private Button Edit_OKButton;
    }
}