﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class RecipeList : UserControl
    {
        public event EventHandler CloseRequested;
        public RecipeList()
        {
            InitializeComponent();
        }

        private void RecipeList_Load(object sender, EventArgs e)
        {
            LoadData();

            //dgv_Recipes.Columns["Instructions"].Width = 500;
        }

        private void LoadData()
        {
            SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            SqlCommand cmd = new(@"SELECT R.*, M.Name AS DishName FROM Recipes R INNER JOIN Meals M ON R.IDMeal = M.IDMeal", con);

            AddViewRecipeButtonColumn();

            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dgv_Recipes.DataSource = dt;

            dgv_Recipes.Columns["DishName"].DisplayIndex = 1;
            //dgv_Recipes.Columns["View"].DisplayIndex = dgv_Recipes.Columns.Count - 1;
        }

        private void AddViewRecipeButtonColumn()
        {
            DataGridViewButtonColumn viewButton = new DataGridViewButtonColumn();
            viewButton.HeaderText = "View";
            viewButton.Name = "View";
            viewButton.Text = "View";
            viewButton.UseColumnTextForButtonValue = true;
            dgv_Recipes.Columns.Add(viewButton);
        }

        private void CloseBtn_Click(object sender, EventArgs e)
        {
            CloseRequested?.Invoke(this, EventArgs.Empty);
        }

        private int GetRecipeID(int dishID)
        {
            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = "SELECT IDRecipe FROM Recipes WHERE IDMeal = @IDMeal";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IDMeal", dishID);

                con.Open();
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : -1;
            }
        }

        private RecipeDetailUC recipeDetail;
        private void dgv_Recipes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgv_Recipes.Columns["View"].Index && e.RowIndex >= 0)
            {
                int dishID = Convert.ToInt32(dgv_Recipes.Rows[e.RowIndex].Cells["IDMeal"].Value);

                int recipeID = GetRecipeID(dishID);
                if (recipeID > 0)
                {
                    recipeDetail = new RecipeDetailUC(dishID, recipeID);
                    recipeDetail.CloseRequested += RecipeDetail_CloseRequested;
                    panelRecipe.Controls.Add(recipeDetail);
                    recipeDetail.Dock = DockStyle.Fill;
                    recipeDetail.BringToFront();
                }
                else
                {
                    MessageBox.Show("No recipe exists for this dish.", "Recipe Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        public void RecipeDetail_CloseRequested(object sender, EventArgs e)
        {
            var recipeDetail = panelRecipe.Controls.OfType<RecipeDetailUC>().FirstOrDefault();
            if (recipeDetail != null && panelRecipe.Controls.Contains(recipeDetail))
            {
                panelRecipe.Controls.Remove(recipeDetail);
                recipeDetail.Dispose();
                recipeDetail = null;
            }
        }

        private void txtBoxSearch_TextChanged(object sender, EventArgs e)
        {
            string searchValue = txtBoxSearch.Text.Trim();

            if (dgv_Recipes.DataSource is BindingSource bindingSource && bindingSource.DataSource is DataTable mealTable)
            {
                if (string.IsNullOrEmpty(searchValue))
                {
                    bindingSource.RemoveFilter();
                    return;
                }
                bindingSource.Filter = $"DishName LIKE '%{searchValue}%'";
            }

            else if (dgv_Recipes.DataSource is DataTable mealtable)
            {
                try
                {
                    if (string.IsNullOrEmpty(searchValue))
                    {
                        LoadData();
                        return;
                    }

                    var filteredData = mealtable.AsEnumerable().Where(row => row.Field<string>("DishName").StartsWith(searchValue, StringComparison.OrdinalIgnoreCase));

                    if (filteredData.Any())
                    {
                        dgv_Recipes.DataSource = filteredData.CopyToDataTable();
                    }
                    else
                    {
                        dgv_Recipes.DataSource = mealtable.Clone();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error filtering dishes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
