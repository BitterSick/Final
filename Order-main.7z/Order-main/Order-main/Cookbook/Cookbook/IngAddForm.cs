﻿using Ingredients;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

//namespace Cookbook
//{
//    public partial class IngAddForm : Form
//    {
//        private SqlDataAdapter dataAdapter;
//        private DataTable dataTable;
//        public System.Windows.Forms.DataGridView IngDataGridView;
//        public IngAddForm()
//        {
//            InitializeComponent();
//        }

//        private void AddButton_Click(object sender, EventArgs e)
//        {
//            string ingredientName = txtName.Text.Trim();
//            if (!string.IsNullOrEmpty(ingredientName))
//            {
//                ingredientName = char.ToUpper(ingredientName[0]) + ingredientName.Substring(1).ToLower();
//                txtName.Text = ingredientName;
//            }

//            if(DoesIngredientExist(ingredientName))
//            {
//                MessageBox.Show("This ingredient already exists in the database.", "Duplicate entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
//                return;
//            }

//            try
//            {
//                using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
//                {
//                    con.Open();
//                    string insertQuery = "INSERT INTO Ingredients (Name, Description, UnitType, Created) VALUES (@Name, @Description, @UnitType, GETDATE())";

//                    using (SqlCommand cmd = new SqlCommand(insertQuery, con))
//                    {
//                        cmd.Parameters.AddWithValue("@Name", txtName.Text);
//                        cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
//                        cmd.Parameters.AddWithValue("@UnitType", comboBox_UnitType.Text);

//                        MessageBox.Show(cmd.ExecuteNonQuery() > 0 ? "Insert Successful." : "Insert Error.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
//                    }
//                }


//                this.DialogResult = DialogResult.OK;

//                this.Close();

//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }

//        }

//        private bool DoesIngredientExist(string ingredientName)
//        {
//            bool exists = false;

//            using (SqlConnection conn = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
//            {
//                string query = "SELECT COUNT(*) FROM Ingredients WHERE Name = @Name";
//                using (SqlCommand cmd = new SqlCommand(query, conn))
//                {
//                    cmd.Parameters.AddWithValue("@Name", ingredientName);
//                    conn.Open();
//                    int count = (int)cmd.ExecuteScalar();
//                    exists = (count > 0);
//                }
//            }
//            return exists;
//        }


//            private void LoadData()
//        {
//            string connectionString = "Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
//            string query = "SELECT * FROM Ingredients";

//            using (SqlConnection connection = new SqlConnection(connectionString))
//            {
//                dataAdapter = new SqlDataAdapter(query, connection);
//                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(dataAdapter);

//                dataTable = new DataTable();
//                dataAdapter.Fill(dataTable);

//            }
//        }

//        private void textBox2_KeyDown(object sender, KeyEventArgs e)
//        {
//            if (e.KeyCode == Keys.Enter)
//            {
//                e.SuppressKeyPress = true;
//                SelectNextControl((Control)sender, true, true, true, true);
//            }
//        }

//        private void textBox1_KeyDown(object sender, KeyEventArgs e)
//        {
//            if (e.KeyCode == Keys.Enter)
//            {
//                e.SuppressKeyPress = true;
//                SelectNextControl((Control)sender, true, true, true, true);
//            }
//        }

//        private void textBox3_KeyDown(object sender, KeyEventArgs e)
//        {
//            if (e.KeyCode == Keys.Enter)
//            {
//                e.SuppressKeyPress = true;
//                comboBox_UnitType.Focus();
//                comboBox_UnitType.DroppedDown = true;
//            }
//        }

//        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
//        {
//            if (e.KeyCode == Keys.Enter)
//            {
//                e.SuppressKeyPress = true;
//                AddButton.Focus();
//            }
//        }

//        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
//        {
//            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
//            {
//                e.Handled = true;
//            }
//        }

//        private void CloseButton_Click(object sender, EventArgs e)
//        {
//            this.Close();
//        }


//    }
//}
