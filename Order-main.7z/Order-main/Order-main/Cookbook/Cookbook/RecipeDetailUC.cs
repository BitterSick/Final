﻿using Ingredients;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class RecipeDetailUC : UserControl
    {
        public event EventHandler CloseRequested;

        private int dishID;
        private int recipeID;

        public RecipeDetailUC(int dishID, int recipeID)
        {
            InitializeComponent();
            this.dishID = dishID;
            this.recipeID = recipeID;
        }

        public void RecipeDetailUC_Load(object sender, EventArgs e)
        {
            LoadIngredients(dishID, recipeID);
            LoadRecipe();
        }

        private void LoadIngredients(int dishID, int recipeID)
        {
            dgv_Ingredients.Rows.Clear();
            dgv_Ingredients.Columns.Clear();

            // Add columns to the DataGridView if they don't already exist
            if (dgv_Ingredients.Columns.Count == 0)
            {
                dgv_Ingredients.Columns.Add("IngredientName", "Name");
                dgv_Ingredients.Columns.Add("Quantity", "Quantity");
                dgv_Ingredients.Columns.Add("Unit", "Unit");
            }

            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                // Retrieve ingredients from the Meals table
                string mealQuery = "SELECT Ingredients FROM Meals WHERE IDMeal = @IDMeal";
                SqlCommand mealCmd = new SqlCommand(mealQuery, con);
                mealCmd.Parameters.AddWithValue("@IDMeal", dishID);

                con.Open();
                string ingredientsList = string.Empty;

                using (SqlDataReader mealReader = mealCmd.ExecuteReader())
                {
                    if (mealReader.Read())
                    {
                        ingredientsList = mealReader["Ingredients"].ToString();
                    }
                }

                if (!string.IsNullOrEmpty(ingredientsList))
                {
                    // Split the ingredient list
                    string[] ingredients = ingredientsList.Split(',');

                    foreach (string ingredient in ingredients)
                    {
                        string ingredientName = ingredient.Trim();
                        decimal quantity = 0;
                        string unit = null;

                        // Retrieve Quantity and Unit from the RecipesIngredients table
                        string recipeQuery = @"SELECT Quantity,Unit FROM RecipesIngredients WHERE IDRecipe = @IDRecipe AND IDIngredient = (SELECT IDIngredient FROM Ingredients WHERE Name = @IngredientName)";

                        SqlCommand recipeCmd = new SqlCommand(recipeQuery, con);
                        recipeCmd.Parameters.AddWithValue("@IDRecipe", recipeID);
                        recipeCmd.Parameters.AddWithValue("@IngredientName", ingredientName);

                        using (SqlDataReader recipeReader = recipeCmd.ExecuteReader())
                        {
                            if (recipeReader.Read())
                            {
                                quantity = recipeReader["Quantity"] != DBNull.Value ? Convert.ToDecimal(recipeReader["Quantity"]) : 0;
                                unit = recipeReader["Unit"]?.ToString();
                            }
                        }

                        // Add data to the DataGridView
                        dgv_Ingredients.Rows.Add(ingredientName, quantity, unit);
                    }
                }
            }
        }

        private void LoadRecipe()
        {
            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = @"SELECT R.Time, R.Difficulty, R.Instructions, M.Name AS DishName, M.Picture FROM Recipes R INNER JOIN Meals M ON R.IDMeal = M.IDMeal WHERE M.IDMeal = @IDMeal";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IDMeal", dishID);

                con.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        txtName.Text = reader["DishName"].ToString();
                        txtTime.Text = reader["Time"].ToString();
                        txtDifficulty.Text = reader["Difficulty"].ToString();
                        txtInstructions.Text = reader["Instructions"].ToString();

                        if (reader["Picture"] != DBNull.Value)
                        {
                            byte[] pictureData = (byte[])reader["Picture"];
                            using (MemoryStream ms = new MemoryStream(pictureData))
                            {
                                pictureBoxDish.Image = Image.FromStream(ms);
                            }
                        }
                        else
                        {
                            pictureBoxDish.Image = null;
                        }
                    }

                    else
                    {
                        MessageBox.Show("Recipe not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            CloseRequested?.Invoke(this, EventArgs.Empty);
        }
    }
}
