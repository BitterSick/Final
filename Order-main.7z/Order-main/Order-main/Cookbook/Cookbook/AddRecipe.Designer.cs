﻿namespace Cookbook
{
    partial class AddRecipe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel5 = new TableLayoutPanel();
            label2 = new Label();
            dgv_ingredientsAmount = new DataGridView();
            txtInstructions = new TextBox();
            label1 = new Label();
            btnCreateRecipe = new Button();
            tableLayoutPanel4 = new TableLayoutPanel();
            label3 = new Label();
            Time_comboBox = new ComboBox();
            Diff_comboBox = new ComboBox();
            Difficulty = new Label();
            label5 = new Label();
            txtName = new TextBox();
            tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_ingredientsAmount).BeginInit();
            tableLayoutPanel4.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 2;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38.91444F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 61.085556F));
            tableLayoutPanel5.Controls.Add(label2, 1, 0);
            tableLayoutPanel5.Controls.Add(dgv_ingredientsAmount, 0, 1);
            tableLayoutPanel5.Controls.Add(txtInstructions, 1, 1);
            tableLayoutPanel5.Controls.Add(label1, 0, 0);
            tableLayoutPanel5.Controls.Add(btnCreateRecipe, 1, 2);
            tableLayoutPanel5.Location = new Point(15, 217);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 3;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 4F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 90F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 6F));
            tableLayoutPanel5.Size = new Size(1150, 700);
            tableLayoutPanel5.TabIndex = 17;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(450, 0);
            label2.Name = "label2";
            label2.Size = new Size(126, 23);
            label2.TabIndex = 4;
            label2.Text = "Instructions";
            // 
            // dgv_ingredientsAmount
            // 
            dgv_ingredientsAmount.AllowUserToAddRows = false;
            dgv_ingredientsAmount.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv_ingredientsAmount.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_ingredientsAmount.Location = new Point(3, 31);
            dgv_ingredientsAmount.Name = "dgv_ingredientsAmount";
            dgv_ingredientsAmount.RowHeadersWidth = 62;
            dgv_ingredientsAmount.Size = new Size(404, 616);
            dgv_ingredientsAmount.TabIndex = 0;
            dgv_ingredientsAmount.CellValidating += dgv_ingredientsAmount_CellValidating;
            // 
            // txtInstructions
            // 
            txtInstructions.Location = new Point(450, 31);
            txtInstructions.Multiline = true;
            txtInstructions.Name = "txtInstructions";
            txtInstructions.Size = new Size(648, 616);
            txtInstructions.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(3, 0);
            label1.Name = "label1";
            label1.Size = new Size(122, 23);
            label1.TabIndex = 4;
            label1.Text = "Ingredients";
            // 
            // btnCreateRecipe
            // 
            btnCreateRecipe.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            btnCreateRecipe.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCreateRecipe.Location = new Point(752, 661);
            btnCreateRecipe.Name = "btnCreateRecipe";
            btnCreateRecipe.Size = new Size(395, 36);
            btnCreateRecipe.TabIndex = 5;
            btnCreateRecipe.Text = "Create";
            btnCreateRecipe.UseVisualStyleBackColor = true;
            btnCreateRecipe.Click += btnCreateRecipe_Click;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.2164F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 87.7836F));
            tableLayoutPanel4.Controls.Add(label3, 0, 0);
            tableLayoutPanel4.Controls.Add(Time_comboBox, 1, 2);
            tableLayoutPanel4.Controls.Add(Diff_comboBox, 1, 1);
            tableLayoutPanel4.Controls.Add(Difficulty, 0, 1);
            tableLayoutPanel4.Controls.Add(label5, 0, 2);
            tableLayoutPanel4.Controls.Add(txtName, 1, 0);
            tableLayoutPanel4.Location = new Point(18, 12);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 3;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 32.7165031F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 34.6029434F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 32.6805534F));
            tableLayoutPanel4.Size = new Size(904, 160);
            tableLayoutPanel4.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Fill;
            label3.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(104, 52);
            label3.TabIndex = 4;
            label3.Text = "Name";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Time_comboBox
            // 
            Time_comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            Time_comboBox.FormattingEnabled = true;
            Time_comboBox.Items.AddRange(new object[] { ">15min", "30min", "45min", "1hr", "1-2hr", "+2hr" });
            Time_comboBox.Location = new Point(113, 110);
            Time_comboBox.Name = "Time_comboBox";
            Time_comboBox.Size = new Size(749, 33);
            Time_comboBox.TabIndex = 3;
            // 
            // Diff_comboBox
            // 
            Diff_comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            Diff_comboBox.FormattingEnabled = true;
            Diff_comboBox.Items.AddRange(new object[] { "Beginner", "Easy", "Advanced", "Hard", "Expert" });
            Diff_comboBox.Location = new Point(113, 55);
            Diff_comboBox.Name = "Diff_comboBox";
            Diff_comboBox.Size = new Size(749, 33);
            Diff_comboBox.TabIndex = 2;
            // 
            // Difficulty
            // 
            Difficulty.AutoSize = true;
            Difficulty.Dock = DockStyle.Fill;
            Difficulty.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Difficulty.Location = new Point(3, 52);
            Difficulty.Name = "Difficulty";
            Difficulty.Size = new Size(104, 55);
            Difficulty.TabIndex = 0;
            Difficulty.Text = "Difficulty";
            Difficulty.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Fill;
            label5.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(3, 107);
            label5.Name = "label5";
            label5.Size = new Size(104, 53);
            label5.TabIndex = 1;
            label5.Text = "Time";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtName
            // 
            txtName.Font = new Font("Arial Rounded MT Bold", 13F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtName.Location = new Point(113, 3);
            txtName.Name = "txtName";
            txtName.ReadOnly = true;
            txtName.Size = new Size(739, 38);
            txtName.TabIndex = 5;
            // 
            // AddRecipe
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1178, 944);
            Controls.Add(tableLayoutPanel5);
            Controls.Add(tableLayoutPanel4);
            Name = "AddRecipe";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AddRecipe";
            Load += AddRecipe_Load;
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgv_ingredientsAmount).EndInit();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private TableLayoutPanel tableLayoutPanel5;
        private DataGridView dgv_ingredientsAmount;
        private TextBox txtInstructions;
        private TableLayoutPanel tableLayoutPanel4;
        private Label Difficulty;
        private Label label5;
        private ComboBox Diff_comboBox;
        private ComboBox Time_comboBox;
        private Label label2;
        private Label label1;
        private Label label3;
        private Button btnCreateRecipe;
        private TextBox txtName;
    }
}