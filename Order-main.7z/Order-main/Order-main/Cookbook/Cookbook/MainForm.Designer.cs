﻿namespace Ingredients
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            label5 = new Label();
            menuStrip1 = new MenuStrip();
            dishToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem7 = new ToolStripMenuItem();
            toolStripMenuItem3 = new ToolStripMenuItem();
            ingredientsListToolStripMenuItem = new ToolStripMenuItem();
            recipeToolStripMenuItem = new ToolStripMenuItem();
            recipeListToolStripMenuItem = new ToolStripMenuItem();
            panelContainer = new Panel();
            tlpCookingRec = new TableLayoutPanel();
            DGV_Available = new DataGridView();
            DGV_Selected = new DataGridView();
            btFindDish = new Button();
            btnReset = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            tlpSearch = new TableLayoutPanel();
            txtSearch = new TextBox();
            btnCookingRec = new Button();
            label6 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            Dishes_DataGridView = new DataGridView();
            label4 = new Label();
            contextMenuStrip2 = new ContextMenuStrip(components);
            addDishToolStripMenuItem = new ToolStripMenuItem();
            editDishToolStripMenuItem = new ToolStripMenuItem();
            deleteDishToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem6 = new ToolStripMenuItem();
            editRecipeToolStripMenuItem = new ToolStripMenuItem();
            exitAppliationToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            panelContainer.SuspendLayout();
            tlpCookingRec.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DGV_Available).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DGV_Selected).BeginInit();
            tlpSearch.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Dishes_DataGridView).BeginInit();
            contextMenuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label5.Location = new Point(79, 306);
            label5.Name = "label5";
            label5.Size = new Size(0, 36);
            label5.TabIndex = 5;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(24, 24);
            menuStrip1.Items.AddRange(new ToolStripItem[] { dishToolStripMenuItem, toolStripMenuItem3, recipeToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1678, 33);
            menuStrip1.TabIndex = 20;
            menuStrip1.Text = "menuStrip1";
            // 
            // dishToolStripMenuItem
            // 
            dishToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { toolStripMenuItem7 });
            dishToolStripMenuItem.Name = "dishToolStripMenuItem";
            dishToolStripMenuItem.Size = new Size(63, 29);
            dishToolStripMenuItem.Text = "Dish";
            // 
            // toolStripMenuItem7
            // 
            toolStripMenuItem7.Name = "toolStripMenuItem7";
            toolStripMenuItem7.Size = new Size(201, 34);
            toolStripMenuItem7.Text = "Create new";
            toolStripMenuItem7.Click += CreateNewtoolStripMenuItem_Click;
            // 
            // toolStripMenuItem3
            // 
            toolStripMenuItem3.DropDownItems.AddRange(new ToolStripItem[] { ingredientsListToolStripMenuItem });
            toolStripMenuItem3.Name = "toolStripMenuItem3";
            toolStripMenuItem3.Size = new Size(117, 29);
            toolStripMenuItem3.Text = "Ingredients";
            // 
            // ingredientsListToolStripMenuItem
            // 
            ingredientsListToolStripMenuItem.Name = "ingredientsListToolStripMenuItem";
            ingredientsListToolStripMenuItem.Size = new Size(230, 34);
            ingredientsListToolStripMenuItem.Text = "Ingredients list";
            ingredientsListToolStripMenuItem.Click += ingredientsListToolStripMenuItem_Click;
            // 
            // recipeToolStripMenuItem
            // 
            recipeToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { recipeListToolStripMenuItem });
            recipeToolStripMenuItem.Name = "recipeToolStripMenuItem";
            recipeToolStripMenuItem.Size = new Size(79, 29);
            recipeToolStripMenuItem.Text = "Recipe";
            // 
            // recipeListToolStripMenuItem
            // 
            recipeListToolStripMenuItem.Name = "recipeListToolStripMenuItem";
            recipeListToolStripMenuItem.Size = new Size(192, 34);
            recipeListToolStripMenuItem.Text = "Recipe list";
            recipeListToolStripMenuItem.Click += recipeListToolStripMenuItem_Click;
            // 
            // panelContainer
            // 
            panelContainer.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panelContainer.Controls.Add(tlpCookingRec);
            panelContainer.Controls.Add(tlpSearch);
            panelContainer.Controls.Add(tableLayoutPanel1);
            panelContainer.Controls.Add(label5);
            panelContainer.Location = new Point(7, 40);
            panelContainer.Name = "panelContainer";
            panelContainer.Size = new Size(1650, 1300);
            panelContainer.TabIndex = 21;
            // 
            // tlpCookingRec
            // 
            tlpCookingRec.ColumnCount = 3;
            tlpCookingRec.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlpCookingRec.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            tlpCookingRec.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tlpCookingRec.Controls.Add(DGV_Available, 0, 1);
            tlpCookingRec.Controls.Add(DGV_Selected, 1, 1);
            tlpCookingRec.Controls.Add(btFindDish, 1, 2);
            tlpCookingRec.Controls.Add(btnReset, 0, 2);
            tlpCookingRec.Controls.Add(label1, 2, 1);
            tlpCookingRec.Controls.Add(label2, 0, 0);
            tlpCookingRec.Controls.Add(label3, 1, 0);
            tlpCookingRec.Location = new Point(9, 105);
            tlpCookingRec.Name = "tlpCookingRec";
            tlpCookingRec.RowCount = 3;
            tlpCookingRec.RowStyles.Add(new RowStyle(SizeType.Percent, 5F));
            tlpCookingRec.RowStyles.Add(new RowStyle(SizeType.Percent, 85F));
            tlpCookingRec.RowStyles.Add(new RowStyle(SizeType.Percent, 10F));
            tlpCookingRec.Size = new Size(1588, 470);
            tlpCookingRec.TabIndex = 14;
            // 
            // DGV_Available
            // 
            DGV_Available.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_Available.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV_Available.Dock = DockStyle.Fill;
            DGV_Available.Location = new Point(3, 26);
            DGV_Available.Name = "DGV_Available";
            DGV_Available.RowHeadersWidth = 62;
            DGV_Available.Size = new Size(470, 393);
            DGV_Available.TabIndex = 0;
            DGV_Available.CellContentClick += DGV_Available_CellContentClick;
            // 
            // DGV_Selected
            // 
            DGV_Selected.AllowUserToAddRows = false;
            DGV_Selected.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            DGV_Selected.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_Selected.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV_Selected.Location = new Point(479, 26);
            DGV_Selected.Name = "DGV_Selected";
            DGV_Selected.RowHeadersWidth = 62;
            DGV_Selected.Size = new Size(470, 393);
            DGV_Selected.TabIndex = 8;
            DGV_Selected.CellContentClick += DGV_Selected_CellContentClick;
            // 
            // btFindDish
            // 
            btFindDish.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btFindDish.BackColor = SystemColors.ActiveBorder;
            btFindDish.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btFindDish.Location = new Point(479, 425);
            btFindDish.Name = "btFindDish";
            btFindDish.Size = new Size(470, 42);
            btFindDish.TabIndex = 9;
            btFindDish.Text = "Find dish";
            btFindDish.UseVisualStyleBackColor = false;
            btFindDish.Click += btFindDish_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = SystemColors.ActiveBorder;
            btnReset.Dock = DockStyle.Fill;
            btnReset.Font = new Font("Arial Rounded MT Bold", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnReset.Location = new Point(3, 425);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(470, 42);
            btnReset.TabIndex = 10;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = false;
            btnReset.Click += btnReset_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Fill;
            label1.Font = new Font("Arial", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(955, 23);
            label1.Name = "label1";
            label1.Size = new Size(630, 399);
            label1.TabIndex = 11;
            label1.Text = resources.GetString("label1.Text");
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Bottom;
            label2.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(3, 0);
            label2.Name = "label2";
            label2.Size = new Size(470, 23);
            label2.TabIndex = 12;
            label2.Text = "Click on + button to add";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Bottom;
            label3.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(479, 0);
            label3.Name = "label3";
            label3.Size = new Size(470, 23);
            label3.TabIndex = 13;
            label3.Text = "Your selected ingredients:";
            // 
            // tlpSearch
            // 
            tlpSearch.ColumnCount = 2;
            tlpSearch.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpSearch.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 272F));
            tlpSearch.Controls.Add(txtSearch, 0, 1);
            tlpSearch.Controls.Add(btnCookingRec, 1, 1);
            tlpSearch.Controls.Add(label6, 0, 0);
            tlpSearch.Location = new Point(6, 6);
            tlpSearch.Name = "tlpSearch";
            tlpSearch.RowCount = 2;
            tlpSearch.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            tlpSearch.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            tlpSearch.Size = new Size(1004, 93);
            tlpSearch.TabIndex = 13;
            // 
            // txtSearch
            // 
            txtSearch.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            txtSearch.CausesValidation = false;
            txtSearch.Location = new Point(3, 30);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(726, 31);
            txtSearch.TabIndex = 0;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // btnCookingRec
            // 
            btnCookingRec.BackColor = SystemColors.ScrollBar;
            btnCookingRec.Dock = DockStyle.Fill;
            btnCookingRec.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCookingRec.Location = new Point(735, 30);
            btnCookingRec.Name = "btnCookingRec";
            btnCookingRec.Size = new Size(266, 60);
            btnCookingRec.TabIndex = 1;
            btnCookingRec.Text = "Dish recommendation";
            btnCookingRec.UseVisualStyleBackColor = false;
            btnCookingRec.Click += btnCookingRec_Click;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            label6.AutoSize = true;
            label6.Font = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(3, 0);
            label6.Name = "label6";
            label6.Size = new Size(113, 27);
            label6.TabIndex = 2;
            label6.Text = "Search bar";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Controls.Add(Dishes_DataGridView, 0, 1);
            tableLayoutPanel1.Controls.Add(label4, 0, 0);
            tableLayoutPanel1.Location = new Point(9, 581);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 5.0005F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 94.9995041F));
            tableLayoutPanel1.Size = new Size(1626, 711);
            tableLayoutPanel1.TabIndex = 12;
            // 
            // Dishes_DataGridView
            // 
            Dishes_DataGridView.AllowUserToAddRows = false;
            Dishes_DataGridView.AllowUserToOrderColumns = true;
            Dishes_DataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            Dishes_DataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Dishes_DataGridView.Dock = DockStyle.Fill;
            Dishes_DataGridView.Location = new Point(3, 38);
            Dishes_DataGridView.Name = "Dishes_DataGridView";
            Dishes_DataGridView.ReadOnly = true;
            Dishes_DataGridView.RowHeadersWidth = 62;
            Dishes_DataGridView.Size = new Size(1620, 670);
            Dishes_DataGridView.TabIndex = 11;
            Dishes_DataGridView.CellContentClick += dataGridView1_CellContentClick;
            Dishes_DataGridView.CellFormatting += Dishes_DataGridView_CellFormatting;
            Dishes_DataGridView.CellMouseDown += dataGridView1_CellMouseDown;
            Dishes_DataGridView.MouseDown += dataGridView1_MouseDown;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(3, 9);
            label4.Name = "label4";
            label4.Size = new Size(93, 26);
            label4.TabIndex = 12;
            label4.Text = "Dish list";
            // 
            // contextMenuStrip2
            // 
            contextMenuStrip2.ImageScalingSize = new Size(24, 24);
            contextMenuStrip2.Items.AddRange(new ToolStripItem[] { addDishToolStripMenuItem, editDishToolStripMenuItem, deleteDishToolStripMenuItem, toolStripMenuItem6, editRecipeToolStripMenuItem, exitAppliationToolStripMenuItem });
            contextMenuStrip2.Name = "contextMenuStrip2";
            contextMenuStrip2.Size = new Size(199, 196);
            // 
            // addDishToolStripMenuItem
            // 
            addDishToolStripMenuItem.Name = "addDishToolStripMenuItem";
            addDishToolStripMenuItem.Size = new Size(198, 32);
            addDishToolStripMenuItem.Text = "Add dish";
            addDishToolStripMenuItem.Click += addDishToolStripMenuItem_Click;
            // 
            // editDishToolStripMenuItem
            // 
            editDishToolStripMenuItem.Name = "editDishToolStripMenuItem";
            editDishToolStripMenuItem.Size = new Size(198, 32);
            editDishToolStripMenuItem.Text = "Edit dish";
            editDishToolStripMenuItem.Click += editDishToolStripMenuItem_Click;
            // 
            // deleteDishToolStripMenuItem
            // 
            deleteDishToolStripMenuItem.Name = "deleteDishToolStripMenuItem";
            deleteDishToolStripMenuItem.Size = new Size(198, 32);
            deleteDishToolStripMenuItem.Text = "Delete dish";
            deleteDishToolStripMenuItem.Click += deleteDishToolStripMenuItem_Click;
            // 
            // toolStripMenuItem6
            // 
            toolStripMenuItem6.Name = "toolStripMenuItem6";
            toolStripMenuItem6.Size = new Size(198, 32);
            toolStripMenuItem6.Text = "Add Recipe";
            toolStripMenuItem6.Click += toolStripMenuItem6_Click;
            // 
            // editRecipeToolStripMenuItem
            // 
            editRecipeToolStripMenuItem.Name = "editRecipeToolStripMenuItem";
            editRecipeToolStripMenuItem.Size = new Size(198, 32);
            editRecipeToolStripMenuItem.Text = "Edit Recipe";
            editRecipeToolStripMenuItem.Click += editRecipeToolStripMenuItem_Click;
            // 
            // exitAppliationToolStripMenuItem
            // 
            exitAppliationToolStripMenuItem.Name = "exitAppliationToolStripMenuItem";
            exitAppliationToolStripMenuItem.Size = new Size(198, 32);
            exitAppliationToolStripMenuItem.Text = "Exit Appliation";
            exitAppliationToolStripMenuItem.Click += exitAppliationToolStripMenuItem_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1678, 1344);
            ContextMenuStrip = contextMenuStrip2;
            Controls.Add(panelContainer);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            MinimumSize = new Size(1637, 1398);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            Load += MainForm_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            panelContainer.ResumeLayout(false);
            panelContainer.PerformLayout();
            tlpCookingRec.ResumeLayout(false);
            tlpCookingRec.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DGV_Available).EndInit();
            ((System.ComponentModel.ISupportInitialize)DGV_Selected).EndInit();
            tlpSearch.ResumeLayout(false);
            tlpSearch.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Dishes_DataGridView).EndInit();
            contextMenuStrip2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label5;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem editTableToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem deleteToolStripMenuItem1;
        private ToolStripMenuItem addNewToolStripMenuItem;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem toolStripMenuItem5;
        private ToolStripMenuItem viewToolStripMenuItem;
        private ToolStripDropDownMenu toolStripTextBox1;
        private ToolStripMenuItem ingredientsToolStripMenuItem;
        private ToolStripMenuItem mealToolStripMenuItem;
        private ToolStripMenuItem createNewToolStripMenuItem;
        private ToolStripMenuItem recipesToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem2;
        private Panel panelContainer;
        private ToolStripMenuItem listToolStripMenuItem;
        public DataGridView Dishes_DataGridView;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tlpSearch;
        private TextBox txtSearch;
        private TableLayoutPanel tlpCookingRec;
        private DataGridView DGV_Available;
        private DataGridView DGV_Selected;
        private Button btFindDish;
        private Button btnReset;
        private Button btnCookingRec;
        private ToolStripMenuItem addRecipeToolStripMenuItem1;
        private ToolStripMenuItem addRecipeToolStripMenuItem;
        private ToolStripMenuItem dishToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem3;
        private ToolStripMenuItem ingredientsListToolStripMenuItem;
        private ToolStripMenuItem recipeToolStripMenuItem;
        private ContextMenuStrip contextMenuStrip2;
        private ToolStripMenuItem addDishToolStripMenuItem;
        private ToolStripMenuItem editDishToolStripMenuItem;
        private ToolStripMenuItem deleteDishToolStripMenuItem;
        private ToolStripMenuItem toolStripMenuItem6;
        private ToolStripMenuItem toolStripMenuItem7;
        private ToolStripMenuItem recipeListToolStripMenuItem;
        private ToolStripMenuItem editRecipeToolStripMenuItem;
        private ToolStripMenuItem exitAppliationToolStripMenuItem;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
    }
}
