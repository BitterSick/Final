﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class MainFormControl: UserControl
    {
        public MainFormControl()
        {
            //InitializeComponent();
        }
    }
}
