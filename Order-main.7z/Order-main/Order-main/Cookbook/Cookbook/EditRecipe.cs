﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class EditRecipe : Form
    {
        private int dishID;
        private int recipeID;
        private string dishName;
        public EditRecipe(int dishID, int recipeID, string dishName)
        {
            InitializeComponent();
            this.dishID = dishID;
            this.recipeID = recipeID;
            this.dishName = dishName;
        }

        private void EditRecipe_Load(object sender, EventArgs e)
        {
            LoadIngredients(dishID, recipeID);
            LoadRecipeDetails(recipeID);
        }

        private void LoadIngredients(int dishID, int recipeID)
        {
            dgv_Ingredients.Rows.Clear();
            dgv_Ingredients.Columns.Clear();

            if (dgv_Ingredients.Columns.Count == 0)
            {
                dgv_Ingredients.Columns.Add("Name", "Name");
                dgv_Ingredients.Columns.Add("Quantity", "Quantity");

                DataGridViewComboBoxColumn unitColumn = new DataGridViewComboBoxColumn();
                unitColumn.HeaderText = "Unit";
                unitColumn.Name = "Unit";
                unitColumn.DataSource = new List<string> { "g", "kg", "ml", "l", "tsp", "tbsp", "cup" };
                dgv_Ingredients.Columns.Add(unitColumn);
            }

            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                // Retrieve ingredients from the Meals table
                string mealQuery = "SELECT Ingredients FROM Meals WHERE IDMeal = @IDMeal";
                SqlCommand mealCmd = new SqlCommand(mealQuery, con);
                mealCmd.Parameters.AddWithValue("@IDMeal", dishID);

                con.Open();
                string ingredientsList = string.Empty;

                using (SqlDataReader mealReader = mealCmd.ExecuteReader())
                {
                    if (mealReader.Read())
                    {
                        ingredientsList = mealReader["Ingredients"].ToString();
                    }
                }

                if (!string.IsNullOrEmpty(ingredientsList))
                {
                    // Split the ingredient list
                    string[] ingredients = ingredientsList.Split(',');

                    foreach (string ingredient in ingredients)
                    {
                        string ingredientName = ingredient.Trim();
                        decimal quantity = 0;
                        string unit = null;

                        // Retrieve Quantity and Unit from the RecipesIngredients table
                        string recipeQuery = @"SELECT RI.Quantity, RI.Unit FROM RecipesIngredients RI INNER JOIN Ingredients I ON RI.IDIngredient = I.IDIngredient WHERE RI.IDRecipe = @IDRecipe AND I.Name = @Name";

                        SqlCommand recipeCmd = new SqlCommand(recipeQuery, con);
                        recipeCmd.Parameters.AddWithValue("@IDRecipe", recipeID);
                        recipeCmd.Parameters.AddWithValue("@Name", ingredientName);

                        using (SqlDataReader recipeReader = recipeCmd.ExecuteReader())
                        {
                            if (recipeReader.Read())
                            {
                                quantity = recipeReader["Quantity"] != DBNull.Value ? Convert.ToDecimal(recipeReader["Quantity"]) : 0;
                                unit = recipeReader["Unit"]?.ToString();
                            }
                        }

                        // Add data to the DataGridView
                        dgv_Ingredients.Rows.Add(ingredientName, quantity, unit);
                    }
                }
            }
        }

        private void LoadRecipeDetails(int recipeID)
        {
            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = @"SELECT Meals.Name, Recipes.Difficulty, Recipes.Time, Recipes.Instructions FROM Recipes INNER JOIN Meals ON Recipes.IDMeal = Meals.IDMeal WHERE Recipes.IDRecipe = @IDRecipe";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IDRecipe", recipeID);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        txtName.Text = reader["Name"]?.ToString();
                        Diff_comboBox.Text = reader["Difficulty"]?.ToString();
                        Time_comboBox.Text = reader["Time"]?.ToString();
                        txtInstructions.Text = reader["Instructions"]?.ToString();
                    }
                }
            }
        }

        private void btnSaveRecipe_Click(object sender, EventArgs e)
        {
            try
            {
                //string updatedName = txtName.Text;
                //string updateDifficulty = Diff_comboBox.SelectedItem?.ToString();
                //string updatedTime = Time_comboBox.SelectedItem?.ToString();
                //string updatedInstructions = txtInstructions.Text;

                using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    string updateRecipeQuery = @"UPDATE Recipes SET Instructions = @Instructions, Difficulty = @Difficulty, Time = @Time WHERE IDRecipe = @IDRecipe";

                    SqlCommand cmd = new SqlCommand(updateRecipeQuery, con);
                    cmd.Parameters.AddWithValue("@Instructions", txtInstructions.Text);
                    cmd.Parameters.AddWithValue("@Difficulty", Diff_comboBox.Text);
                    cmd.Parameters.AddWithValue("@Time", Time_comboBox.Text);
                    cmd.Parameters.AddWithValue("@IDRecipe", recipeID);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    string deleteIngQuery = "DELETE FROM RecipesIngredients WHERE IDRecipe = @IDRecipe";
                    SqlCommand deleteCmd = new SqlCommand(deleteIngQuery, con);
                    deleteCmd.Parameters.AddWithValue("@IDRecipe", recipeID);

                    con.Open();
                    deleteCmd.ExecuteNonQuery();

                    foreach (DataGridViewRow row in dgv_Ingredients.Rows)
                    {
                        if (row.Cells["Name"].Value != null && row.Cells["Quantity"].Value != null && row.Cells["Unit"].Value != null)
                        {
                            string ingredientName = row.Cells["Name"].Value.ToString();
                            decimal quantity = Convert.ToDecimal(row.Cells["Quantity"].Value);
                            string unit = row.Cells["Unit"].Value.ToString();

                            string ingQuery = "SELECT IDIngredient FROM Ingredients WHERE Name = @Name";
                            SqlCommand ingCmd = new SqlCommand(ingQuery, con);
                            ingCmd.Parameters.AddWithValue("@Name", ingredientName);

                            int ingredientID = 0;
                            using (SqlDataReader ingReader = ingCmd.ExecuteReader())
                            {
                                if (ingReader.Read())
                                {
                                    ingredientID = Convert.ToInt32(ingReader["IDIngredient"]);
                                }
                            }

                            if (ingredientID > 0)
                            {
                                string insertIngQuery = @"INSERT INTO RecipesIngredients (IDRecipe, IDIngredient, Quantity, Unit) VALUES (@IDRecipe, @IDIngredient, @Quantity, @Unit)";
                                SqlCommand insertIngCmd = new SqlCommand(insertIngQuery, con);
                                insertIngCmd.Parameters.AddWithValue("@IDRecipe", recipeID);
                                insertIngCmd.Parameters.AddWithValue("@IDIngredient", ingredientID);
                                insertIngCmd.Parameters.AddWithValue("@Quantity", quantity);
                                insertIngCmd.Parameters.AddWithValue("@Unit", unit);

                                insertIngCmd.ExecuteNonQuery();
                            }
                        }
                    }
                }

                MessageBox.Show("Recipe updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating recipe: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }


    }
}
