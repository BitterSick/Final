﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class AddRecipe : Form
    {
        private int dishID;
        public AddRecipe(int dishID, string dishName)
        {
            InitializeComponent();
            this.dishID = dishID;

            txtName.Text = dishName;
            LoadSelectedIngredients(dishID);
        }

        private void AddRecipe_Load(object sender, EventArgs e)
        {
            Setup_DataGridView();
        }

        private void LoadSelectedIngredients(int dishID)
        {
            dgv_ingredientsAmount.Rows.Clear();
            dgv_ingredientsAmount.Columns.Clear();

            if (dgv_ingredientsAmount.Columns.Count == 0)
            {
                dgv_ingredientsAmount.Columns.Add("IngredientName", "Name");
            }

            using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                string query = "SELECT Ingredients FROM Meals WHERE IDMeal = @IDMeal";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@IDmeal", dishID);

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    string ingredientsList = reader["Ingredients"].ToString();

                    string[] ingredients = ingredientsList.Split(',');
                    foreach (string ingredient in ingredients)
                    {
                        dgv_ingredientsAmount.Rows.Add(ingredient.Trim(), 0, null);
                    }
                }
            }
        }

        private void Setup_DataGridView()
        {
            //Quantity column
            DataGridViewTextBoxColumn qColumn = new DataGridViewTextBoxColumn();
            qColumn.HeaderText = "Quantity";
            qColumn.Name = "Quantity";
            dgv_ingredientsAmount.Columns.Add(qColumn);

            //Unit Column
            DataGridViewComboBoxColumn unitColumn = new DataGridViewComboBoxColumn();
            unitColumn.HeaderText = "Unit";
            unitColumn.Name = "Unit";
            unitColumn.DataSource = new List<string> { "g", "kg", "ml", "l", "tsp", "tbsp", "cup" };
            dgv_ingredientsAmount.Columns.Add(unitColumn);


            dgv_ingredientsAmount.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void dgv_ingredientsAmount_CellValidating(object sender, DataGridViewCellValidatingEventArgs e) 
        {
            if (dgv_ingredientsAmount.Columns[e.ColumnIndex].Name == "Quantity")
            {
                string inputValue = e.FormattedValue.ToString();

                if (string.IsNullOrEmpty(inputValue))
                {
                    MessageBox.Show("Please enter amount for the ingredient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    e.Cancel = true;
                }
            }
        }

        private void btnCreateRecipe_Click(object sender, EventArgs e)
        {
            string recipeName = txtName.Text;
            string difficulty = Diff_comboBox.SelectedItem?.ToString();
            string instructions = txtInstructions.Text.Trim();
            string time = Time_comboBox.Text.Trim();

            if (string.IsNullOrEmpty(time))
            {
                MessageBox.Show("Please select a cooking time.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (string.IsNullOrEmpty(difficulty))
            {
                MessageBox.Show("Please select a difficulty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if (string.IsNullOrEmpty(instructions) || instructions.Length < 10)
            {
                MessageBox.Show("Instructions must be at least 10 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection("Data Source=TUAN007\\MSSQLSERVER01;Initial Catalog=Gastronomy;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    con.Open();
                    string query = "INSERT INTO Recipes (IDMeal, Time, Instructions, Difficulty, Created) VALUES (@IDMeal, @Time, @Instructions, @Difficulty, GETDATE())";


                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@IDMeal", dishID);
                        cmd.Parameters.AddWithValue("@Time", time);
                        cmd.Parameters.AddWithValue("@Instructions", instructions);
                        cmd.Parameters.AddWithValue("@Difficulty", string.IsNullOrEmpty(difficulty) ? DBNull.Value : difficulty);

                        cmd.ExecuteNonQuery();
                    }


                    int newRecipeID = GetRecipeID(con, instructions);
                    foreach (DataGridViewRow row in dgv_ingredientsAmount.Rows)
                    {
                        if (row.IsNewRow) continue;

                        string ingredientName = row.Cells["IngredientName"].Value?.ToString();
                        decimal quantity = 0;
                        string unit = row.Cells["Unit"].Value?.ToString();

                        if (!decimal.TryParse(row.Cells["Quantity"].Value?.ToString(), out quantity) || string.IsNullOrEmpty(ingredientName))
                        {
                            MessageBox.Show("Please ensure all ingredients have a valid name and quantity.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        int ingredientID = GetIngredientID(con, ingredientName);
                        if (ingredientID == 0)
                        {
                            MessageBox.Show($"Ingredient '{ingredientName}' does not exist in the database.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }


                            string ingQuery = "INSERT INTO RecipesIngredients(IDRecipe, IDIngredient, Quantity, Unit) VALUES (@IDRecipe, @IDIngredient, @Quantity, @Unit)";
                            using (SqlCommand cmd = new SqlCommand(ingQuery, con))
                            {
                                cmd.Parameters.AddWithValue("@IDRecipe", newRecipeID);
                                cmd.Parameters.AddWithValue("@IDIngredient", ingredientID);
                                cmd.Parameters.AddWithValue("@Quantity", quantity);
                                cmd.Parameters.AddWithValue("@Unit", string.IsNullOrEmpty(unit) ? DBNull.Value : unit);

                                cmd.ExecuteNonQuery();
                            }
                    }
                    MessageBox.Show("Recipe created successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving recipe: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetIngredientID(SqlConnection con, string ingredientName)
        {
            string query = "SELECT IDIngredient FROM Ingredients WHERE Name = @Name";

            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Name", ingredientName);
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }

        private int GetRecipeID(SqlConnection con, string instructions)
        {
            string query = "SELECT IDRecipe FROM Recipes WHERE Instructions = @Instructions";

            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Instructions", instructions);
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }
    }
}
